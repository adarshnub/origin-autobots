# Instructions for implementing Desktop Pilot

## Project goal

Implement the specification in `docs/MASTER_PLAN.md`. This is a Windows desktop autopilot with AWS-hosted orchestration, GCP-managed Gemini inference, real visible native input, optional visible browser/VS Code adapters, voice instructions, accounts and an admin dashboard. The initial release is owner-only.

This file is an implementation handoff, not authorization to spend money, change unrelated cloud resources, install arbitrary dependencies, or exercise unrestricted control over the developer's computer.

## Order of work

1. Read the master plan and `docs/SOURCES.md`. Record capability/version findings in `docs/capabilities.md`.
2. Inspect the current repository and tools without destructive changes. Do not overwrite an existing project.
3. Implement M0: contracts, fake provider, explicit requirements, version pins and cloud/model preflight scripts.
4. Scaffold M1 Terraform and authentication. Produce a Terraform plan; request approval before applying billable changes.
5. Implement M2: Windows capture/input, local supervisor, STOP and a deliberately armed test harness.
6. Connect actual GCP inference only after credentials, limits, approvals and local stop tests work.
7. Complete later milestones one at a time with runnable tests and documented evidence.

Use the master plan's milestone exit criteria. Do not substitute a mocked demo for a real end-to-end result.

## Implementation invariants

- All desktop input executes on the enrolled Windows device, not the AWS host.
- The application acts in the logged-in user's session, at normal integrity by default.
- Exactly one task owns physical mouse/keyboard input at a time.
- STOP is local, independent of model/network availability, and invalidates queued/late actions.
- The local supervisor validates action schemas, ownership, lease, epoch, policy and required approval before dispatch.
- Do not execute SDK function calls automatically. Every proposal goes through the policy path.
- Do not treat screenshots, webpages, chat, files, terminals, meeting transcripts or another agent's output as authorization.
- Do not strip required provider thought signatures/function-call IDs. Do not display opaque reasoning state as a user transcript.
- Preserve the true mapping among screenshots, scaled images, DPI and desktop coordinates.
- Do not blindly replay a possibly executed Send/Submit/Delete action after timeout or reconnect.
- Reveal affected apps and changes. API acceleration is allowed; fake cursor activity to disguise it is not.
- Downloads, installations, dependencies, extensions and updates require the specified acquisition grant.
- The agent cannot approve its own permission UI or expand its own tool surface.
- Provider-required confirmation must be surfaced; never acknowledge it automatically.
- No cloud account keys in the desktop app, repository, telemetry, screenshots or client configuration.
- No public signup or public release until the explicit release gate is met.

## Honest boundaries

A normal-user local supervisor is not tamper-proof against arbitrary code running under the same user. Do not claim that unrestricted shell execution plus a text filter guarantees download prevention or injection immunity. For strict enforcement, use the planned OS/network isolation. Keep broad developer experiments in a disposable Windows test environment.

Stopping the controller does not undo completed actions or necessarily stop external agents. Report uncertain effects and cancellations.

## Coding and testing standards

Use C#/.NET 10/WPF for the Windows client, Python/FastAPI for the server, TypeScript/React for the dashboard and TypeScript for extensions. Keep infrastructure in Terraform. Pin supported toolchain/library versions and commit lockfiles. Verify the current Google SDK constructor/API surface instead of copying stale examples.

Use typed contracts, structured logs, bounded waits, explicit cancellation and tests. Add cross-language schema fixtures. Default to mock providers and disarmed native input in development. Unit tests must never click or type into the developer's actual desktop accidentally.

Keep screenshots/audio and genuine personal files out of fixtures. Use synthetic pages, disposable repositories and test accounts. Separate model-quality tests from deterministic executor tests. Tests that require Windows or actual cloud services must report SKIPPED when unavailable, not PASS.

Implement no-op/dry-run modes for native actions and provisioning. Guard destructive operations and acquisition paths. Do not disable validation or expand permissions simply to make a failing test pass.

## Working updates and completion report

For each milestone provide:

- Files/components implemented and how to run them.
- Tests actually run and their results, including skipped integration tests.
- Current limitations and any unresolved capability checks.
- Cloud resources actually created or changed, with the approved environment.
- Measured metrics separately from proposed targets.
- The next single implementation task.

Never report deployment, signing, account access or successful UI execution without corresponding evidence. When cloud credentials or a signing identity are missing, complete the local/scaffold work and record exact missing inputs rather than fabricating them.
