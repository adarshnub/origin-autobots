# Desktop Pilot — Codex planning package

This package is a researched design handoff, **not source code for a working app** and **not a cloud deployment**.

Start with `MASTER_PLAN.md` for the architecture and phased implementation. `CODEX_START.md` contains the first task to give a coding agent. Put `AGENTS.md` in the new repository root. `config.example.yaml` supplies a proposed configuration surface with sensitive/account-specific values unset. `acceptance-tests.md` defines the test gates. `SOURCES.md` records the primary documentation reviewed on 25 September 2026.

The first real implementation goal is an authenticated Windows screenshot → GCP model → locally validated visible action → verification loop, with a STOP path that works offline. Browser/VS Code acceleration, voice and the developer dashboard follow that foundation. Calendar and meeting workflows come later.

Cloud account IDs, model entitlements, domain ownership, credentials, costs and latency have not been verified in the owner's accounts. No AWS/GCP resources were created while preparing this package.
